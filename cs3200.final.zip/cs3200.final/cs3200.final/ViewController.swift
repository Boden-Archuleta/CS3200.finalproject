//
//  ViewController.swift
//  cs3200.final
//
//  Created by Student on 3/30/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

var filters = [
    "CIPhotoEffectChrome",
    "CIPhotoEffectFade",
    "CIPhotoEffectInstant",
    "CIBumpDistortionLinear",
    "CICircleSplashDistortion",
    "CICircularWrap"
]

class ViewController: UIViewController {
    @IBOutlet weak var oldImage: UIImageView!
    @IBOutlet weak var newImage: UIImageView!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var scrollBar: UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        for i in 0..<filters.count{
            let fButton = UIButton(type: .custom)
            
            
            
            scrollBar.addSubview(fButton)
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

